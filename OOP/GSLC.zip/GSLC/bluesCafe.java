import java.util.Scanner;
import java.util.ArrayList;

public class bluesCafe {
    Scanner input = new Scanner(System.in);
    ArrayList<customerTable> tables = new ArrayList<customerTable>();
    ArrayList<tableOrder> orders = new ArrayList<tableOrder>();

    double totalCash = 0;

    public void addOrder() {
        tableOrder newOrder = new tableOrder(null, totalCash, 0);
        customerTable newTable = new customerTable(0, 0, totalCash);

        // table number input
        System.out.print("Input table number : ");
        while (!input.hasNextInt()) {
            System.out.println("Input error.");
            System.out.println("Input table number : ");
            input.next();
        }
        int tableNumber = input.nextInt();
        input.nextLine();
        // newTable.tableNumber = tableNumber;

        // gatekeeper
        // System.out.println("Table Number succeed.");

        char key;
        do {

            // order input
            System.out.print("Input order : ");
            while (input.hasNextInt()) {
                System.out.println("Input error.");
                System.out.print("Input Order : ");
                input.next();
                input.nextLine();
            }
            String orderName = input.nextLine();

            // gatekeeper
            // System.out.println("Order succeed.");

            // quantity input
            System.out.print("Input quantity : ");
            while (!input.hasNextInt()) {
                System.out.println("Input error.");
                System.out.print("Input quantity : ");
                input.next();
            }
            int orderQuantity = input.nextInt();
            input.nextLine();

            // gatekeeper
            // System.out.println("Quantity succeed.");

            // price per quantity input
            System.out.print("Input price (in one quantity) : Rp");
            while (!input.hasNextInt()) {
                System.out.println("Input error.");
                System.out.print("Input price (in one quantity) : ");
                input.next();
            }
            double orderPrice = input.nextDouble();
            input.nextLine();

            // gatekeeper
            // System.out.println("Price succeed.");

            orders.add(newOrder);

            System.out.print("Do you want to add another order [y/n] ?\n>> ");
            key = Character.toLowerCase(input.nextLine().charAt(0));

        } while (key == 'y');

        tables.add(newTable);
    }

    public void showOrders() {

        System.out.print("Table number : ");
        
        int tableNumberKey = 0;
        tableNumberKey = input.nextInt();
        input.nextLine();

        System.out.println("====================================");
        System.out.println("| Quantity\t|| Name\t||\tPrice\t|");
        System.out.println("====================================");

        for (int i = 0; i < tables.size(); i++) {
            if (tables.get(i).getTableNumber() == tableNumberKey) {
                for (int j = 0; j < orders.size(); j++) {
                    System.out.print("" + orders.get(j).getFoodQuantity() + "\t");
                    System.out.print(orders.get(j).getFoodOrder() + "\t");
                    System.out.println("Rp" + orders.get(j).getFoodPrice());
                }
            }
        }

        // for (customerTable table : tables) {
        // // if (table.getTableNumber() == tableNumber) {
        // for (int i) {
        // // System.out.print("" + list.getFoodQuantity() + "\t");
        // // System.out.print(list.getFoodOrder() + "\t");
        // // System.out.println("Rp" + list.getFoodPrice());
        // }
        // // }
        // }
    }

    public void removeOrder() {

    }

    public void exit() {

    }

    public void header() {
        String logo = " ___ _                ___       __     \n" +
                "| _ ) |_  _ ___ ___  / __|__ _ / _|___ \n" +
                "| _ \\ | || / -_|_-< | (__/ _` |  _/ -_)\n" +
                "|___/_|\\_,_\\___/__/  \\___\\__,_|_| \\___|\n\n" +
                "Total earned money : Rp" + totalCash +
                "\n=======================================";

        System.out.println(logo);
    }

    public int Menu() {

        System.out.println("1. Add Order");
        System.out.println("2. Show All Order");
        System.out.println("3. Remove Order");
        System.out.println("4. Exit");
        System.out.print(">> ");

        while (!input.hasNextInt()) {
            System.out.println("Wrong input.");
            System.out.print(">> ");
            input.next();
        }
        int key = input.nextInt();
        return key;
    }

    public static void main(String[] args) {

        bluesCafe main = new bluesCafe();
        int key;
        do {
            main.header();
            key = main.Menu();

            switch (key) {
                case 1:
                    main.addOrder();
                    break;

                case 2:
                    main.showOrders();
                    break;

                case 3:
                    main.removeOrder();
            }
        } while (key != 4);

    }

}
